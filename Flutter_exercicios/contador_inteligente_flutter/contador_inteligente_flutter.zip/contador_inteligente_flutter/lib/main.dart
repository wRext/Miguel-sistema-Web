import 'package:flutter/material.dart';

void main() {
  runApp(const ContadorApp());
}

class ContadorApp extends StatelessWidget {
  const ContadorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contador Inteligente',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const ContadorPage(),
    );
  }
}

class ContadorPage extends StatefulWidget {
  const ContadorPage({super.key});

  @override
  State<ContadorPage> createState() => _ContadorPageState();
}

class _ContadorPageState extends State<ContadorPage> {
  int contador = 0;

  void alterarValor(int valor) {
    // Não permite números negativos
    setState(() {
      contador += valor;
      if (contador < 0) contador = 0;
      // Mostra uma mensagem especial quando chegar a 100
      if (contador == 100) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("😱Uau chegou no 100!! Boaa!💯")),
        );
      }
    });
  }
      // Inicia em 0
  void resetar() {
    setState(() {
      contador = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Contador Inteligente")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "$contador",
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                color: contador > 0 ? Colors.green : Colors.red,
              ),
            ),
            const SizedBox(height: 20),
            Wrap(
              // Tem botões para +1, -1, +5, -5
              spacing: 10,
              children: [
                ElevatedButton(
                    onPressed: () => alterarValor(1), child: const Text("+1")),
                ElevatedButton(
                    onPressed: () => alterarValor(-1), child: const Text("-1")),
                ElevatedButton(
                    onPressed: () => alterarValor(5), child: const Text("+5")),
                ElevatedButton(
                    onPressed: () => alterarValor(-5), child: const Text("-5")),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: resetar,
              style: ElevatedButton.styleFrom(backgroundColor: const Color.fromARGB(255, 34, 2, 75)),
              child: const Text("Resetar"),
            ),
          ],
        ),
      ),
    );
  }
}
