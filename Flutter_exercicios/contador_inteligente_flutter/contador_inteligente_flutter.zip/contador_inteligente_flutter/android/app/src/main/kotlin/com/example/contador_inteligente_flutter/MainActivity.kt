package com.example.contador_inteligente_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
