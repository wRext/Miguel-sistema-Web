import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() {
  runApp(const MinhaApp());
}

class MinhaApp extends StatelessWidget {
  const MinhaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Título "Minha Primeira App Flutter"
      title: 'Minha Primeira App Flutter',
      theme: ThemeData(primarySwatch: Colors.blue),
      debugShowCheckedModeBanner: false,

      // 🔹 Correção aqui:
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations
            .delegate, // necessário para Cupertino (iOS-like)
      ],
      supportedLocales: const [
        Locale('pt', 'BR'), // português Brasil
        Locale('en', 'US'), // inglês EUA
      ],

      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Color backgroundColor = Colors.lightBlue[100]!; // cor inicial

  void mudarCor() {
    setState(() {
      // Muda a cor de fundo da tela alternando entre azul e verde
      backgroundColor = backgroundColor == Colors.lightBlue[100]
          ? Colors.green[100]!
          : Colors.lightBlue[100]!;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        title: const Text("Minha Primeira App Flutter"),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Seu nome em destaque
            const Text(
              "Carlos Eduardo",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),
            const SizedBox(height: 20),
            // Um botão que mostra um alerta com "Olá Flutter!" e troca o fundo
            ElevatedButton(
              onPressed: () {
                mudarCor(); // muda o fundo
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text("Mensagem"),
                    content: const Text("Olá Flutter!"),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text("OK"),
                      ),
                    ],
                  ),
                );
              },
              child: const Text("Clique aqui"),
            ),
          ],
        ),
      ),
    );
  }
}
