package com.example.minha_primeira_aplicacao

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
